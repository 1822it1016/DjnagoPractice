from django.shortcuts import render
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import serializers
from .serializers import SchoolSerializer
# Create your views here.
from .models import School


class SchoolView(APIView):

    def get(self, request):
        students = School.objects.all()
        return Response({
            "data": students.values(),
            "msg": "Data fetched successfully"
        })

    def post(self, request):
        serializer = SchoolSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({"data": serializer.data,
                             "msg": "data inserted successfully"
                             })

        return Response({
            "msg": "unable to validate the serializer"
        })

    def delete(self, request):
        try:
            name = request.query_params.get("name")
            School.objects.filter(name=name).delete()
            return Response({
                "msg": name + " deleted Successfully"
            })
        except:
            return Response({
                "msg": name + " not found in Database"
            })
