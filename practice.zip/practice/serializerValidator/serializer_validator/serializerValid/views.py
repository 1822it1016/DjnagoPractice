# Create your views here.
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.status import HTTP_400_BAD_REQUEST, HTTP_200_OK, HTTP_404_NOT_FOUND, HTTP_500_INTERNAL_SERVER_ERROR
from .serializers import CustomizationSerializer


class CustomizationView(APIView):
    # http_method_names = ['get', 'put']

    def put(self, request):
        """
            Registers new customization if not present or updates the exiting if required.

            Expects the request in CustomizationSerializer format.

            Params:
                request: -> request payload.

            Returns:
                200 -> if the request is valid and the customization is registered.
                400 -> if the request was invalid or the operation was a failure.
        """

        customization_serializer = CustomizationSerializer(data=request.data)

        if customization_serializer.is_valid():
            #
            # if request.data["metadata"]["trigger"] not in MODULE_TRIGGER_MAPPING[
            #     customization_serializer.data["metadata"]["module"]]:
            #     return Response({
            #         "message": "Error while registering the customization",
            #         "error": {
            #             "message": customization_serializer.data["metadata"][
            #                            "module"] + " should be mapped with " +
            #                        str(MODULE_TRIGGER_MAPPING[
            #                                customization_serializer.data["metadata"]["module"]]),
            #             "code": 400
            #         }},
            #         status=HTTP_400_BAD_REQUEST)
            validated_data = customization_serializer.validated_data
            # customization_id = self._customization_service.create_or_update(
            #     validated_data["data"]["customizations"],
            #     validated_data["metadata"])
        else:
            errors = str(customization_serializer.errors)

        return Response({
            "message": "Successfully registered the customization",
            "data": {
                "id": "akash"
            }
        }, status=HTTP_200_OK)
