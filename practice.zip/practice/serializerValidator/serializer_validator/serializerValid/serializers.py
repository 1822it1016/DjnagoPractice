from rest_framework import serializers
from .constants import MODULE_TRIGGER_MAPPING

module_name = ""


class TextValueValidator:
    requires_context = True

    def __init__(self, validation_set, is_upper: bool = False):
        self._validation_set = validation_set
        self._is_upper = is_upper

    def __call__(self, raw_value, serializer):
        """
            Validates the raw value for the attribute on the basis of validation set provided.

            Params ->
                raw_value -> value which is provided in the request attribute
                serializer -> internal serializer having the request information.
            Raises ->
                ValidationError -> if the value is not in the validation set.

        """
        field_name = serializer.field_name
        updated_value = raw_value
        if raw_value in list(MODULE_TRIGGER_MAPPING.keys()):
            module_name = raw_value.upper()
        if self._is_upper:
            updated_value = raw_value.upper()


class ConfigOperationSerializer(serializers.Serializer):
    key = serializers.CharField(required=True)
    value = serializers.CharField(required=True)
    regex = serializers.CharField(required=False)
    condition = serializers.CharField(required=False)
    true_value = serializers.CharField(required=False)
    false_value = serializers.CharField(required=False)


class OperationSerializer(serializers.Serializer):
    operation = serializers.CharField(required=True,
                                      validators=[TextValueValidator(["HARDCODE", "REGEX_REPLACE", "IIF"],
                                                                     is_upper=True)])
    config = ConfigOperationSerializer(required=True)


class DataCustomizationSerializer(serializers.Serializer):
    customizations = OperationSerializer(many=True)


class MetadataCustomizationSerializer(serializers.Serializer):
    source_system = serializers.CharField(required=True)
    destination_system = serializers.CharField(required=True)
    tenant_id = serializers.CharField(required=False, default="ST")
    module = serializers.CharField(required=True,
                                   validators=[TextValueValidator(list(MODULE_TRIGGER_MAPPING.keys()), is_upper=True)])
    trigger = serializers.CharField(required=True,
                                    validators=[
                                        TextValueValidator(MODULE_TRIGGER_MAPPING.get(module_name, []), is_upper=True)])
    data_format = serializers.CharField(required=True,
                                        validators=[TextValueValidator(["HL7", "FHIR"], is_upper=True)])


class CustomizationSerializer(serializers.Serializer):
    data = DataCustomizationSerializer()
    metadata = MetadataCustomizationSerializer()
