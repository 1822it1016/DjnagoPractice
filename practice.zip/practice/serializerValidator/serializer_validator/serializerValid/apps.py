from django.apps import AppConfig


class SerializervalidConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'serializerValid'
