from django.shortcuts import render
from rest_framework.views import APIView
from os.path import exists
import json
from .serializers import StudentSerializer
from rest_framework.response import Response
from .models import Student

c = 0


# Create your views here.
class MessageSerializer(APIView):
    def post(self, request):
        c = 0
        try:
            serializer = StudentSerializer(data=request.data)
            if serializer.is_valid():
                if (request.data["firstname"] == "Akash"):
                    if request.data["middlename"] in request.data:
                        c += 1
                    else:
                        Response({
                            "msg": "middle name must be present"
                        })
                # student = Student(firstname=serializer.data["firstname"],
                #                   lastname=serializer.data["lastname"],
                #                   middlename=serializer.data["middlename"],
                #                   branch=serializer.data["branch"]
                #                   )
                # student.save()
                return Response({
                    "msg": serializer.data['firstname'] + " registered successfully",
                    "type": str(type(json.loads(serializer.data)))
                })
            return Response({
                "msg": "unable to " + serializer.data['firstname'] + " registered successfully",
                "type": str(type(json.load(request.data)))

            })

        except Exception as exp:
            return Response({
                "msg": "unknown error occured " + str(exp),
                "type": str(type(json.load(request.data)))
            })
