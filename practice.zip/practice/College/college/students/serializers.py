from rest_framework import serializers


class StudentSerializer(serializers.Serializer):
    firstname = serializers.CharField(required=True)
    middlename = serializers.CharField(required=False)
    lastname = serializers.CharField(required=True)
    branch = serializers.CharField(required=True)
