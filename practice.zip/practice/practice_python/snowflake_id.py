import snowflake_id

# Set the epoch to 2021-01-01
epoch = 1609459200000

# Set the worker ID to 1
worker_id = 1

# Set the sequence number to 1
sequence_number = 1

# Generate a unique ID
id = snowflake_id.generate(epoch=epoch, worker_id=worker_id, sequence_number=sequence_number)

for i in range(0,1000):
    print(next(id))
