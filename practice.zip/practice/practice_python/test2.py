from rest_framework import serializers
print(type(serializers))

print(type(serializers.Serializer))

print(type(serializers.CharField()))
