from django.db import models

print("printing models")
print(type(models))
print("\n")
print("printing models.Model")
print(type(models.Model))

print(type(models.CharField()))
