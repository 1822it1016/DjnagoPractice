from snowflake import SnowflakeGenerator 

val = SnowflakeGenerator(64)

for i in range(0,100):
    print(next(val))
