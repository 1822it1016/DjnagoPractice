from rest_framework.response import Response
from rest_framework.decorators import api_view
from .serializers import SchoolSerializer
from .models import School
from django.core.paginator import Paginator


@api_view(['GET'])
def get(request):
    obj = School.objects.all()
    return Response({
        "data": obj.values()
    })


@api_view(['GET'])
def get_by_page_no(request, no):
    obj = School.objects.all()
    paginator = Paginator(obj, 2)
    new_paginated_data = paginator.page(no)
    return Response({"data":list(new_paginated_data)})


@api_view(['GET'])
def get_by_id(request, id):
    try:
        obj = School.objects.filter(id=id)
        if len(obj.values()) == 0:
            return Response({
                "msg": "invalid id"
            })
        return Response({
            "data": obj.values(),
            "msg": "data fetched successfully corresponding to given id " + id
        })
    except:
        return Response({
            "msg": " unknown error occurred "
        })


#
# @api_view(['POST'])
# def post(request):
#     try:
#         req = json.loads(request.body)
#         print(req)
#         obj = School.objects.create(name=req['name'], std=req['std'], section=req['section'],
#                                     singleChild=req['singleChild'])
#         obj.save()
#         return Response({
#             "name": req['name'], "std": req['std'], "section": req['section'], "singleChild": req['singleChild']
#         })


@api_view(['POST'])
def post(request):
    serializer = SchoolSerializer(data=request.data)
    if request.data['name'] == "Pubg":
        return Response({
            "msg": "unable to register with name as Pubg"
        })
    if serializer.is_valid():
        serializer.save()
        return Response({
            "msg": serializer.data['name'] + " regitered succesfully"
        })
    return Response(serializer.errors)


@api_view(['DELETE'])
def delete(request, id):
    School.objects.filter(id=id).delete()
    return Response({
        "msg": id + " deleted successfully"
    })
