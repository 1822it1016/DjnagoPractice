from django.db import models


# Create your models here.

class School(models.Model):
    name = models.CharField(max_length=50)
    std = models.CharField(max_length=10)
    section = models.CharField(max_length=2)
    singleChild = models.BooleanField(default=False)

