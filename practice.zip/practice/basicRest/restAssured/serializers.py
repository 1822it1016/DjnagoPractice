from rest_framework import serializers
from .models import School


# Create your models here.

class SchoolSerializer(serializers.ModelSerializer):
    class Meta:
        model = School
        fields = ('name', 'std', 'section', 'singleChild',)
