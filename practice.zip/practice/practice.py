new_dict = {"akash" : ["newdata","newdata2"]}

if "newdata" in new_dict["akash"]:
	print("done")
    for key,value in new_dict.items():
        print(key," : ",value)
else:
	print("not done")
